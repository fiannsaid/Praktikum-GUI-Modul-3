class Aritmatika:
  @staticmethod
  def tambah(a, b):
    return a + b
  @staticmethod
  def kurang(a, b):
    return a - b
  @staticmethod
  def bagi(a, b):
    return a / b
  @staticmethod
  def bagi_int(a, b):
    return a // b
  @staticmethod
  def pangket(a, b):
    return a ** b
  @staticmethod
print(Aritmatika.tambah(5,5))
objek = Aritmatika()
print(objek.pangkat(2,3))