from abc import ABCMeta,abstractmethod
class DuaDimensi(metaclass=ABCMeta):
  @abstractmethod
  def luas(self):
    pass

class SegiEmpat(DuaDimensi):
  def __init__(self,p,l):
    self.panjang = p
    self.lebar = l
  def luas(self):
    return self.panjang * self.lebar