from abc import ABCMeta, abstractmethod
class DuaDimensi(metaclass=ABCMeta):
    @abstractmethod
    def luas(self):
        pass
class Segiempat(DuaDimensi):
    def __init__(self, p, l):
        self.panjang = p
        self.lebar = l
    def luas(self):
        return self.panjang * self.lebar
class Segitiga(DuaDimensi):
    def __init__(self, a, t):
        self.alas = a
        self.tinggi = t
    def luas(self):
        return (self.alas * self.tinggi) / 2
class Lingkaran(DuaDimensi):
    def __init__(seld, r):
        self.jari2 = r
    def luas(self):
        import math
        return math.pi * (self.jari2**2)
 mylist= []
 mylist.append(Segiempat(10,8))
 mylist.append(Segitiga(3,5))
 mylist.append(Lingkaran(4))

 for obj in mylist:
   if not issubclass(obj.__class__, DuaDimensi):
     raise TypeError('objek harus turunan dari DuaDimensi')
   if isinstance(obj,Segiempat):
     print('Luas Segi Empat = ', end;'')
   elif isinstance(obj, Segitiga):
     print('Luas Segitiga = ',end='')
   else:
     print('Luas Lingkaran = ', end='')
     print(obj.luas)