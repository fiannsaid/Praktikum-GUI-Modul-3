class PersegiPanjang:
  def __init__(self,p,l):
    self.panjang = p
    self.lebar = l
  def ubahPanjang (self,p):
    self.panjang = p
  def ubahLebar (self,l):
    self.lebar = l
  def hitungLuas(self):
    return self.panjang * self.lebar
  def hitungKeliling(self):
    return 2 * (self.panjang + self.lebar)
  def cetakLuas(self):
    print('Luas persegi panjang = %.2f' % self.hitungLuas())
  def cetakKeliling(self):
    print('Keliling persegi Panjang = %.2f' % self.hitungKeliling())
objek = PersegiPanjang(10, 8)
objek.cetakLuas()
objek.cetakKeliling()